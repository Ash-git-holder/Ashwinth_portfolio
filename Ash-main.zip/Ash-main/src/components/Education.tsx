import React from 'react';
import { GraduationCap, Award, BookOpen, Star } from 'lucide-react';

const Education = () => {
  return (
    <section id="education" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-blue-900 mb-4">Education</h2>
          <div className="w-24 h-1 bg-orange-500 mx-auto mb-8"></div>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* Main Education */}
          <div className="bg-gradient-to-br from-blue-50 to-orange-50 p-8 rounded-xl shadow-lg mb-8">
            <div className="flex items-start gap-6">
              <div className="bg-blue-900 p-3 rounded-full">
                <GraduationCap size={32} className="text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-blue-900 mb-2">
                  Bachelor of Technology in Information Technology
                </h3>
                <p className="text-orange-600 font-semibold mb-4">2022 - 2026</p>
                <p className="text-gray-700 mb-4">
                  Kalasalingam Academy of Research and Education, Krishnan koil, Tamil Nadu
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Star size={20} className="text-orange-500 mr-2" />
                      <span className="font-semibold text-blue-900">CGPA</span>
                    </div>
                    <p className="text-2xl font-bold text-orange-500">7.95</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <BookOpen size={20} className="text-orange-500 mr-2" />
                      <span className="font-semibold text-blue-900">Minor</span>
                    </div>
                    <p className="text-lg text-gray-700">Blockchain Technology</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Academic Achievements */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-orange-500">
              <div className="flex items-center mb-4">
                <Award size={24} className="text-orange-500 mr-3" />
                <h4 className="font-bold text-blue-900">Scholarship</h4>
              </div>
              <p className="text-gray-600 mb-2">25% Merit Scholarship</p>
              <p className="text-sm text-gray-500">Kalasalingam University</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-blue-500">
              <div className="flex items-center mb-4">
                <Star size={24} className="text-blue-500 mr-3" />
                <h4 className="font-bold text-blue-900">SSLC</h4>
              </div>
              <p className="text-gray-600 mb-2">96% Score</p>
              <p className="text-sm text-gray-500">Secondary Education</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-500">
              <div className="flex items-center mb-4">
                <BookOpen size={24} className="text-green-500 mr-3" />
                <h4 className="font-bold text-blue-900">HSE</h4>
              </div>
              <p className="text-gray-600 mb-2">76% Score</p>
              <p className="text-sm text-gray-500">Higher Secondary</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;
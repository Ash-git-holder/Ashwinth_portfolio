import React from 'react';
import { Briefcase, Calendar, Shield, Users, CheckCircle } from 'lucide-react';

const Experience = () => {
  const experiences = [
    {
      title: 'Python Intern',
      company: 'AICTE Internship Program',
      duration: 'May 2024',
      type: 'Internship',
      icon: <Briefcase size={24} />,
      description: 'Worked on the project "Secure Online Auction System", focusing on implementing robust cybersecurity measures to protect sensitive transaction data and user integrity.',
      highlights: [
        'Developed core backend functionalities using Python',
        'Implemented encryption, authentication, and secure communication protocols',
        'Gained hands-on experience in designing secure system architecture',
        'Successfully completed and certified by AICTE',
        'Applied best practices in code quality and system security'
      ],
      skills: ['Python', 'Cybersecurity', 'System Architecture', 'Authentication', 'Encryption']
    },
    {
      title: 'Event Organiser & Club Management',
      company: 'Sherlock Holmes Club',
      duration: '2023 - 2026',
      type: 'Leadership Role',
      icon: <Users size={24} />,
      description: 'Actively served as a key member of the Sherlock Holmes Club, contributing to the successful planning and execution of multiple college events.',
      highlights: [
        'Organized engaging games and interactive sessions',
        'Boosted student participation and creativity',
        'Delivered impactful speech gestures and introductions for chief guests',
        'Demonstrated strong public speaking and coordination skills',
        'Proven track record in team collaboration and event success'
      ],
      skills: ['Event Management', 'Public Speaking', 'Team Leadership', 'Coordination', 'Project Management']
    }
  ];

  return (
    <section id="experience" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-blue-900 mb-4">Work Experience</h2>
          <div className="w-24 h-1 bg-orange-500 mx-auto mb-8"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Professional experience gained through internships and leadership roles that have shaped 
            my technical skills and soft skills in real-world environments.
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-8">
          {experiences.map((exp, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="p-8">
                <div className="flex flex-col md:flex-row md:items-start gap-6">
                  {/* Icon and Basic Info */}
                  <div className="flex-shrink-0">
                    <div className="bg-orange-500 p-3 rounded-full text-white mb-4">
                      {exp.icon}
                    </div>
                    <div className="text-center md:text-left">
                      <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-3 py-1 rounded-full">
                        {exp.type}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="mb-4">
                      <h3 className="text-2xl font-bold text-blue-900 mb-2">{exp.title}</h3>
                      <p className="text-orange-600 font-semibold mb-2">{exp.company}</p>
                      <div className="flex items-center text-gray-600 mb-4">
                        <Calendar size={16} className="mr-2" />
                        <span>{exp.duration}</span>
                      </div>
                    </div>

                    <p className="text-gray-700 mb-6 leading-relaxed">{exp.description}</p>

                    {/* Highlights */}
                    <div className="mb-6">
                      <h4 className="font-semibold text-blue-900 mb-3">Key Achievements:</h4>
                      <div className="space-y-2">
                        {exp.highlights.map((highlight, hIndex) => (
                          <div key={hIndex} className="flex items-start">
                            <CheckCircle size={16} className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                            <span className="text-gray-600 text-sm">{highlight}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Skills */}
                    <div>
                      <h4 className="font-semibold text-blue-900 mb-3">Technologies & Skills:</h4>
                      <div className="flex flex-wrap gap-2">
                        {exp.skills.map((skill, sIndex) => (
                          <span
                            key={sIndex}
                            className="bg-orange-100 text-orange-800 text-xs font-medium px-3 py-1 rounded-full"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;
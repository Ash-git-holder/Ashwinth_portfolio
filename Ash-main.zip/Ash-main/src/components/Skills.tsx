import React from 'react';
import { Monitor, Smartphone, Database, Zap, Users, Megaphone } from 'lucide-react';

const Skills = () => {
  const skillCategories = [
    {
      icon: <Monitor size={32} />,
      title: 'Frontend Development',
      skills: ['React.js', 'JavaScript', 'HTML5', 'CSS3', 'Tailwind CSS', 'Responsive Design']
    },
    {
      icon: <Database size={32} />,
      title: 'Backend Development',
      skills: ['Python', 'Flask', 'Node.js', 'RESTful APIs', 'Database Design']
    },
    {
      icon: <Smartphone size={32} />,
      title: 'UI/UX Design',
      skills: ['User Interface Design', 'User Experience', 'Prototyping', 'Design Systems']
    },
    {
      icon: <Zap size={32} />,
      title: 'Emerging Technologies',
      skills: ['Machine Learning', 'Blockchain', 'Web3.js', 'Solidity', 'IoT']
    },
    {
      icon: <Users size={32} />,
      title: 'Soft Skills',
      skills: ['Team Leadership', 'Event Management', 'Public Speaking', 'Problem Solving']
    },
    {
      icon: <Megaphone size={32} />,
      title: 'Additional Skills',
      skills: ['Prompt Engineering', 'Project Management', 'Version Control', 'Agile Methodology']
    }
  ];

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-blue-900 mb-4">Skills & Expertise</h2>
          <div className="w-24 h-1 bg-orange-500 mx-auto mb-8"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            A comprehensive set of technical and soft skills developed through academic projects, 
            internships, and hands-on experience in various technologies.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <div className="text-orange-500 mb-6 flex justify-center">
                {category.icon}
              </div>
              <h3 className="text-xl font-bold text-blue-900 mb-6 text-center">
                {category.title}
              </h3>
              <div className="space-y-3">
                {category.skills.map((skill, skillIndex) => (
                  <div
                    key={skillIndex}
                    className="bg-blue-50 text-blue-900 px-4 py-2 rounded-lg text-center text-sm font-medium hover:bg-orange-50 hover:text-orange-700 transition-colors duration-200"
                  >
                    {skill}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
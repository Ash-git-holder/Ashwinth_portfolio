import React from 'react';
import { Globe, Database, Lightbulb, Cpu, ExternalLink, Github } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: 'Crop Yield Prediction System',
      description: 'Machine Learning-powered web application for predicting crop yields using Flask backend and React.js frontend. Published in IEEE Conference (Paper ID: 0378).',
      icon: <Database size={32} />,
      technologies: ['Python', 'Flask', 'React.js', 'Web3.js', 'Solidity', 'Machine Learning'],
      features: [
        'ML algorithms for accurate crop yield prediction',
        'Blockchain integration for data security',
        'Responsive React.js frontend',
        'RESTful API with Flask backend',
        'Published research paper in IEEE Conference'
      ],
      category: 'Machine Learning',
      status: 'Published Research'
    },
    {
      title: 'Smart Crop Recommendation',
      description: 'Intelligent system that recommends optimal crops based on soil conditions, weather patterns, and historical data using machine learning algorithms.',
      icon: <Lightbulb size={32} />,
      technologies: ['Machine Learning', 'React.js', 'Python', 'Data Analysis'],
      features: [
        'Soil analysis integration',
        'Weather pattern analysis',
        'Historical data processing',
        'Real-time recommendations',
        'User-friendly interface'
      ],
      category: 'Machine Learning',
      status: 'Completed'
    },
    {
      title: 'Cafe Website',
      description: 'Responsive and visually appealing website for a cafe business featuring modern design principles and optimal user experience.',
      icon: <Globe size={32} />,
      technologies: ['HTML5', 'CSS3', 'JavaScript', 'Responsive Design'],
      features: [
        'Fully responsive design',
        'Modern UI/UX principles',
        'Interactive menu display',
        'Contact and location integration',
        'Fast loading performance'
      ],
      category: 'Web Development',
      status: 'Live'
    },
    {
      title: 'Smart Dustbin',
      description: 'IoT-based automated waste management system using ultrasonic sensors and servo motors for efficient waste collection.',
      icon: <Cpu size={32} />,
      technologies: ['Arduino', 'Ultrasonic Sensor', 'Servo Motor', 'IoT', 'C++'],
      features: [
        'Automated lid opening mechanism',
        'Ultrasonic distance detection',
        'Real-time monitoring',
        'Power-efficient design',
        'Easy maintenance'
      ],
      category: 'IoT',
      status: 'Prototype'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Published Research':
        return 'bg-green-100 text-green-800';
      case 'Live':
        return 'bg-blue-100 text-blue-800';
      case 'Completed':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-orange-100 text-orange-800';
    }
  };

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-blue-900 mb-4">Notable Projects</h2>
          <div className="w-24 h-1 bg-orange-500 mx-auto mb-8"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            A showcase of my technical projects spanning web development, machine learning, 
            and IoT, demonstrating practical application of modern technologies.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="bg-white border border-gray-200 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden"
            >
              <div className="p-8">
                {/* Header */}
                <div className="flex items-start justify-between mb-6">
                  <div className="text-orange-500">
                    {project.icon}
                  </div>
                  <div className="flex gap-2">
                    <span className={`text-xs font-semibold px-3 py-1 rounded-full ${getStatusColor(project.status)}`}>
                      {project.status}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-blue-900 mb-3">{project.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{project.description}</p>

                {/* Features */}
                <div className="mb-6">
                  <h4 className="font-semibold text-blue-900 mb-3">Key Features:</h4>
                  <ul className="space-y-2">
                    {project.features.map((feature, fIndex) => (
                      <li key={fIndex} className="text-sm text-gray-600 flex items-start">
                        <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Technologies */}
                <div className="mb-6">
                  <h4 className="font-semibold text-blue-900 mb-3">Technologies:</h4>
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech, tIndex) => (
                      <span
                        key={tIndex}
                        className="bg-blue-50 text-blue-900 text-xs font-medium px-3 py-1 rounded-full"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <button className="flex items-center text-orange-500 hover:text-orange-600 transition-colors duration-200">
                    <ExternalLink size={16} className="mr-2" />
                    <span className="text-sm font-medium">View Details</span>
                  </button>
                  <button className="flex items-center text-blue-900 hover:text-blue-700 transition-colors duration-200">
                    <Github size={16} className="mr-2" />
                    <span className="text-sm font-medium">Source Code</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Project Timeline */}
        <div className="mt-16 text-center">
          <div className="bg-gray-50 p-8 rounded-xl">
            <h3 className="text-2xl font-bold text-blue-900 mb-4">Project Timeline</h3>
            <p className="text-gray-600 mb-6">Active development period</p>
            <div className="flex items-center justify-center">
              <span className="bg-orange-500 text-white px-6 py-2 rounded-full font-semibold">
                2023 - 2026
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;
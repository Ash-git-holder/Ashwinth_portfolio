import React from 'react';
import { Code, Palette, Users, Trophy } from 'lucide-react';

const About = () => {
  const highlights = [
    {
      icon: <Code size={24} />,
      title: 'Fullstack Development',
      description: 'Proficient in modern web technologies including React.js, Python, and Flask'
    },
    {
      icon: <Palette size={24} />,
      title: 'UI/UX Design',
      description: 'Strong eye for aesthetics and user-centered design principles'
    },
    {
      icon: <Users size={24} />,
      title: 'Event Management',
      description: 'Experienced in organizing college events and leading team initiatives'
    },
    {
      icon: <Trophy size={24} />,
      title: 'Academic Excellence',
      description: '7.95 CGPA with 25% scholarship at Kalasalingam University'
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-blue-900 mb-4">About Me</h2>
          <div className="w-24 h-1 bg-orange-500 mx-auto mb-8"></div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div>
            <h3 className="text-2xl font-bold text-blue-900 mb-6">
              Passionate Developer & Designer
            </h3>
            <div className="space-y-4 text-gray-600 leading-relaxed">
              <p>
                I'm a creative and detail-oriented Frontend Developer and UI/UX Designer 
                with a strong passion for crafting seamless user experiences. Currently pursuing 
                my Bachelor's in Information Technology with a minor in blockchain technology 
                at Kalasalingam Academy of Research and Education.
              </p>
              <p>
                My expertise lies in building responsive, accessible, and visually engaging 
                web applications using modern frontend technologies. I excel at translating 
                design concepts into interactive interfaces, with additional proficiency in 
                backend logic using Python and Java.
              </p>
              <p>
                Beyond technical skills, I'm recognized for my leadership abilities, having 
                successfully organized multiple college events and contributed to the Sherlock 
                Holmes Club. I'm known for bridging the gap between design and development, 
                delivering intuitive digital solutions that are both functional and user-centric.
              </p>
            </div>

            {/* Languages */}
            <div className="mt-8">
              <h4 className="text-lg font-semibold text-blue-900 mb-4">Languages</h4>
              <div className="flex flex-wrap gap-3">
                {['Tamil', 'English', 'Telugu', 'Hindi'].map((lang) => (
                  <span
                    key={lang}
                    className="bg-blue-50 text-blue-900 px-4 py-2 rounded-full text-sm font-medium"
                  >
                    {lang}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Right Content - Highlights */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {highlights.map((item, index) => (
              <div
                key={index}
                className="bg-gray-50 p-6 rounded-xl hover:shadow-lg transition-shadow duration-300"
              >
                <div className="text-orange-500 mb-4">
                  {item.icon}
                </div>
                <h4 className="text-lg font-semibold text-blue-900 mb-2">
                  {item.title}
                </h4>
                <p className="text-gray-600 text-sm">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
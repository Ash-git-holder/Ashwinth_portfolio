import React from 'react';
import { Github, Mail, Phone, MapPin, Download } from 'lucide-react';

const Hero = () => {
  const handleDownloadCV = () => {
    // In a real application, you would link to the actual CV file
    alert('CV download functionality would be implemented here');
  };

  return (
    <section id="home" className="min-h-screen flex items-center bg-gradient-to-br from-blue-50 to-orange-50">
      <div className="container mx-auto px-6 py-20">
        <div className="flex flex-col lg:flex-row items-center justify-between">
          {/* Left Content */}
          <div className="lg:w-1/2 mb-12 lg:mb-0">
            <div className="text-sm font-semibold text-orange-500 mb-4 uppercase tracking-wide">
              Welcome to my portfolio
            </div>
            <h1 className="text-5xl lg:text-6xl font-bold text-blue-900 mb-6 leading-tight">
              I'm <span className="text-orange-500">Ashwinth L</span>
            </h1>
            <h2 className="text-2xl lg:text-3xl text-gray-600 mb-8 font-light">
              Fullstack & UI/UX Developer
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed max-w-lg">
              Creative and detail-oriented developer with a passion for crafting seamless user experiences 
              and building robust web applications using modern technologies.
            </p>
            
            {/* Contact Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              <div className="flex items-center text-gray-600">
                <Phone size={18} className="text-orange-500 mr-3" />
                <span>8438547057</span>
              </div>
              <div className="flex items-center text-gray-600">
                <Mail size={18} className="text-orange-500 mr-3" />
                <span>ashwinthsasi@gmail.com</span>
              </div>
              <div className="flex items-center text-gray-600 sm:col-span-2">
                <MapPin size={18} className="text-orange-500 mr-3" />
                <span>Madurai, Tamil Nadu</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={handleDownloadCV}
                className="bg-orange-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-orange-600 transition-colors duration-200 flex items-center justify-center"
              >
                <Download size={20} className="mr-2" />
                Download CV
              </button>
              <a
                href="https://github.com/Ashwinth-coder"
                target="_blank"
                rel="noopener noreferrer"
                className="border-2 border-blue-900 text-blue-900 px-8 py-3 rounded-lg font-semibold hover:bg-blue-900 hover:text-white transition-colors duration-200 flex items-center justify-center"
              >
                <Github size={20} className="mr-2" />
                View GitHub
              </a>
            </div>
          </div>

          {/* Right Content - Profile Image Placeholder */}
          <div className="lg:w-1/2 flex justify-center">
            <div className="w-80 h-80 rounded-full overflow-hidden shadow-2xl">
              <img 
                src="/ash-img.jpg" 
                alt="Ashwinth L"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;